import React, { Component } from 'react'
import '../SectionRight/SectionRight.css'

class SectionRight extends Component {
    render() {
        return (
            <div className='Section-Bar-Right'>
                
            </div>
        )
    }
}


export default SectionRight