

import React, { Component } from 'react'
import '../SectionLeft/SectionLeft.css'

class SectionLeft extends Component {
    render() {
        return (
            <div className='Section-Bar-Left'>
                
            </div>
        )
    }
}


export default SectionLeft