import React, { Component } from "react";
import "../Main/Main.css";

class Main extends Component {
  constructor() {
    super();
    this.state = {
        userArray : [],
        id : 0,
        tr : '',
        data: {
          dataType: "string",
          dataBoll: true,
        },
    };
  }

  

  render() {
    const onCreate = () => {
      let name = document.getElementById("name").value;
      let surname = document.getElementById("surname").value;
      let status = document.getElementById("status").value;
      let university = document.getElementById("university").value;
      let faculty = document.getElementById("faculty").value;
      let contact = document.getElementById("contact").value; 

      if (
        name &&
        surname &&
        status &&
        university &&
        faculty &&
        contact !== ""
      ) {
        this.setState({
            id : this.state.id + 1
        })
        const obj = {
          id: this.state.id,
          userName: name,
          userSurname: surname,
          userStatus: status,
          userUniversity: university,
          userFaculty: faculty,
          userContact: contact,
        };

        this.state.userArray.push(obj);

        // console.log(this.state.userArray);
        

        const onDraw = () => {
                        
            this.state.userArray.forEach((item,index)=>{


                
                console.log(item);
                this.setState({
                    tr : this.state.tr + (
                        <tr>
                          <td>{index}</td>
                          <td>{item.userName}</td>
                          <td>{item.userSurname}</td>
                          <td>{item.userStatus}</td>
                          <td>{item.userUniversity}</td>
                          <td>{item.userFaculty}</td>
                          <td>{item.userContact}</td>
                          <td><button>Edit</button><button>Delete</button></td>
                        </tr>
                      )
                })
            });
            console.log(this.state.tr);
            document.getElementById("tbody").innerHTML = this.state.tr;
           
            
          };

          onDraw();

        document.getElementById("name").value = "";
        document.getElementById("surname").value = "";
        document.getElementById("status").value='';
        document.getElementById("university").value = "";
        document.getElementById("faculty").value = "";
        document.getElementById("contact").value = "";
      } else {
        alert("Fill in the rows completely");
      }
    };

    

    return (
      <div className="Main">
        <div className="Main-Container">
          <div>
            <input id="name" placeholder="name ..." type="text" />
            <input id="surname" placeholder="surname ..." type="text" />
            <input id="status" placeholder="status ..." type="text" />
            <input id="university" placeholder="university ..." type="text" />
            <input id="faculty" placeholder="faculty ..." type="text" />
            <input id="contact" placeholder="contact ..." type="text" />
          </div>
          <button onClick={() => onCreate()}>Create</button>
          <br />
          <br />
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Surname</th>
                <th>Status</th>
                <th>University</th>
                <th>Faculty</th>
                <th>Contact</th>
                <th colSpan="3">Buttons</th>
              </tr>
            </thead>
            <tbody id="tbody">
              
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default Main;
