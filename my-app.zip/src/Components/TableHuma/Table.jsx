import React, { Component } from "react";
import "../TableHuma/Table.css";
import Body from "./Body/Body";
import Footer from "./Footer/Footer";
import Header from "./Head/Header";

class Table extends Component {
  render() {
    return (
      <div className="Container">
        <Header />

        <Body />

        <Footer />
      </div>
    );
  }
}

export default Table;
