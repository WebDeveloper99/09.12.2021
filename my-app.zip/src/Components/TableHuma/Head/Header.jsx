import React, { Component } from 'react'
import '../Head/Header.css'

class Header extends Component {
    render() {
        return (
            <div className='Header'>
                <h1>Header</h1>
            </div>
        )
    }
}


export default Header