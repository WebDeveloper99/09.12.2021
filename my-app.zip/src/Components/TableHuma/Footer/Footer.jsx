import React, { Component } from 'react'
import '../Footer/Footer.css'

export default class Footer extends Component {
    render() {
        return (
            <div className='Footer' >
                <h1>Footer</h1>
            </div>
        )
    }
}
